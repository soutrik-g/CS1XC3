/**
 * @file course.c
 * @author Soutrik Guhathakurta
 * @date 2022-04-10
 * @copyright Copyright (c) 2022
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 /**
  * @brief This function is used to enroll students. It initialises the student array within the typedef struct if it doesn't have any students, otherwise reallocates new memory to the array with one additional space.
  * @param course
  * @param student
  */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1)
  {
    course->students = calloc(1, sizeof(Student));
  }
  else
  {
    course->students =
      realloc(course->students, course->total_students * sizeof(Student));
  }
  course->students[course->total_students - 1] = *student;
}
/**
 * @brief This function prints out the course name, code, total students and all the students enrolled within that course.
 * @param course
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}
/**
 * @param course
 * @return The student with the maximum average in the course.
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 // Sets the value for the current max average in the course to that of the first student
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 // Checks the average of the current student with the average of the next student in the students array and then replaces the value of max average with that of the next student if the average of that student is found to be higher.
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}
/**
 *
 * @param course
 * @param total_passing
 * @return An array of the names of the students who are passing
 */

Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  //Checks the average of every student and increments the variable count every time a students average is above 50 (passing).
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  //allocates memory to the passing students array.
  passing = calloc(count, sizeof(Student));
//Checks the average of every student and adds the student to the passing array if they are passing and assigns the value of the count to the total number of students who are passing
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}