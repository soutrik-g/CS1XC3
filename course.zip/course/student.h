/**
 * @file student.h
 * @author Soutrik Guhathakurta
 * @date 2022-04-10
 * @copyright (c) 2022
 */
 /**
  * This contains the struct Student with its submembers first name, last name, id, grades and the number of grades and the functions required for Student
  */
typedef struct _student 
{ 
  char first_name[50]; /**< First name of the student*/
  char last_name[50]; /**< Last name of the student*/
  char id[11]; /**< Student ID*/
  double *grades; /**< An array of the grades the student obtained*/
  int num_grades;  /**< Number of grades obtained by the student*/
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
