/**
 *@file student.c
 * @author Soutrik Guhathakurta
 * @date 2022-04-10
 * @copyright (c) 2022
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"
/**
 * @brief A
 * @param student
 * @param grade
 */
void add_grade(Student* student, double grade)
{
    //Initializes the grades list if the student didn't have any before it  and allocates memory for it.
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  //If the student had grades before it reallocates new memory to the array as much is the current size of the number of grades
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}
/**
 *
 * @param student
 * @return average grade in the grades list
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;
// sums the total grade then calculates the average.
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}
/**
 * @brief This function prints the Name, ID, grades and the grade average
 * @param student
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  //Prints the grades and Average for the student.
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}
/**
 *
 * @param grades
 * @return All the randomized data and name of the student created from a pool of randomized names for a student.
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));
//Chooses a random first and last name for the student
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);
//Randomizes digits from 0 to 9 and makes a student id by storing the digit to its corresponding index in the char array.
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';
//Assigns random grades for the students.
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}