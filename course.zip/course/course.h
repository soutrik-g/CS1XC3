/**
 * @file course.h
 * @author Soutrik Guhathakurta
 * @date 2022-04-10
 * @copyright (c) 2022
 */
#include "student.h"
#include <stdbool.h>
 /**
  * This contains the Struct Course with its name, code, array of students registered and total number of students and the functions for Course
  */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


